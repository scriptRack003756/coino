Updated May 9/14:
Added Wallet Notify Functions
Updated Version Number

Updated April 7/14: Hard fork at block 269708 to address a blockchain freeze that resulted from a daylight savings time issue in a previous block


rpc port: 14444
network port: 15555

25 seconds between blocks
1 hr retarget time
100m total coins
35 coins per block
